<h2>Enregistrer un Membre</h2>

<?php
/*
 * When we include the partial, we give `true` as second
 * parameter. We check in the partial if this parameter
 * had been set or not to determine so custom texts
 */
include_partial('form', array('form' => $form, 'first' => true))
?>

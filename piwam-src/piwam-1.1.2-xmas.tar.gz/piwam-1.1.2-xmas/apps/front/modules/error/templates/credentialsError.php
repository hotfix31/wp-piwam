<h2>Problème de droits</h2>
<p>Vous n'avez pas les droits suffisants pour effectuer cette action.</p>

<?php
/*
 * Required parameter :
 *
 * $error
 */
?>

<?php if ($error): ?>

    <strong>
        Extension <span style="font-family: courier">php_openssl</span> : absente
    </strong><br />
    Sans cette extension, vous ne pourrez pas envoyer d'e-mails en passant par
    des connexions sécurisées.

<?php else: ?>

    L'extension <span style="font-family: courier">php_openssl</span> est
    correctement lancée.

<?php endif; ?>
<?php

class ConfigVariable extends BaseConfigVariable
{
}

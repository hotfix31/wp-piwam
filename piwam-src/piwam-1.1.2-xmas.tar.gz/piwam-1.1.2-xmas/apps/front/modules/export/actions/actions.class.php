<?php

/**
 * export actions.
 *
 * @package    piwam
 * @subpackage export
 * @author     Adrien Mogenet
 * @version    SVN: $Id: actions.class.php 12479 2008-10-31 10:54:40Z fabien $
 */
class exportActions extends sfActions
{
    /**
     * Provides a view to allows current user to export the different data
     * he wants to export
     *
     * @param   sfWebRequest    $request
     * @since   1.1.2
     */
    public function executeIndex(sfWebRequest $request)
    {
        // does nothing, just display
        // static template

        return sfView::SUCCESS;
    }
}

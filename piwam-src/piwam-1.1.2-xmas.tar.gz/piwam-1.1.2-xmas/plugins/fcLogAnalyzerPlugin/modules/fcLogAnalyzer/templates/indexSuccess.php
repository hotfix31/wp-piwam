<h2>Analyseur de logs</h2>

<table>
    <?php foreach ($logs as $log): ?>
        <tr>
            <td><?php echo $log ?></td>
        </tr>
    <?php endforeach ?>
</table>
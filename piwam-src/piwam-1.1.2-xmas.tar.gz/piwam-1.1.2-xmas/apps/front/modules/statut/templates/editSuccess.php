<h2>Editer un Statut</h2>

<?php include_partial('form', array('form' => $form)) ?>

<h2>Nouveau Statut</h2>

<?php include_partial('form', array('form' => $form)) ?>

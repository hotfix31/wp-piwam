tinyMCE.addI18n('fr.simple',{
bold_desc:"Gras (Ctrl+B)",
italic_desc:"Italique (Ctrl+I)",
underline_desc:"Soulign\u00E9 (Ctrl+U)",
striketrough_desc:"Barr\u00E9",
bullist_desc:"Liste non-num\u00E9rot\u00E9e",
numlist_desc:"Liste num\u00E9rot\u00E9e",
undo_desc:"Annuler (Ctrl+Z)",
redo_desc:"R\u00E9tablir (Ctrl+Y)",
cleanup_desc:"Nettoyer le code non propre"
});
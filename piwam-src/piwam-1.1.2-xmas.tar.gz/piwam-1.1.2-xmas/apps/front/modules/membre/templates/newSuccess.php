<h2>Enregistrer un Membre</h2>

<?php include_partial('form', array('form' => $form)) ?>

<h2>Configuration</h2>

<?php include_partial('form', array('form' => $form)) ?>

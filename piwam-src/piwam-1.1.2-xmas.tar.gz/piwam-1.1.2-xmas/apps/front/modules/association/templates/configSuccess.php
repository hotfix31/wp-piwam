<h2>Configuration</h2>
<?php  if ($sf_user->hasFlash('notice')): ?>
<p class="notice"><?php echo $sf_user->getFlash('notice') ?></p>
<?php endif; ?>
<?php include_partial('configForm', array('form' => $form)) ?>

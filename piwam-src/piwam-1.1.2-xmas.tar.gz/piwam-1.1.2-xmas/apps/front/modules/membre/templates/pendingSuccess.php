<h2>Demande en cours...</h2>
<p>
    Votre demande d'adhésion à l'association a bien été prise en compte.
</p>
<p>
    Si vous avez renseigné une adresse e-mail valide, vous serez prévenu(e)
    dès qu'un administrateur aura validé votre inscription.
</p>
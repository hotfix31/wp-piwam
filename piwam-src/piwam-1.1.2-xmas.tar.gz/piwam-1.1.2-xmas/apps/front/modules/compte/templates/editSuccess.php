<h2>Editer un Compte</h2>

<?php include_partial('form', array('form' => $form)) ?>

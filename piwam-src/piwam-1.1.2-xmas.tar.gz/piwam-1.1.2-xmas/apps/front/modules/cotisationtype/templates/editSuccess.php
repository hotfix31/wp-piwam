<h2>Éditer un type de cotisation</h2>

<?php include_partial('form', array('form' => $form)) ?>

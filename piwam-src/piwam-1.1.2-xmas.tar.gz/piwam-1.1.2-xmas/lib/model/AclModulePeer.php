<?php

class AclModulePeer extends BaseAclModulePeer
{
}

<?php
/*
 * Required parameter :
 *
 * $error
 */
?>

<?php if ($error): ?>

    <strong>
        Extension <span style="font-family: courier">php_gd</span> : absente
    </strong><br />
    Sans cette extension, vous ne pourrez pas associer des photos aux membres
    correctement.

<?php else: ?>

    L'extension <span style="font-family: courier">php_gd</span> est
    correctement lancée.

<?php endif; ?>
<h2>Éditer une activite</h2>

<?php include_partial('form', array('form' => $form)) ?>

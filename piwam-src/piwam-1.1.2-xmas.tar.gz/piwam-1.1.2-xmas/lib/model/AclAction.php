<?php

class AclAction extends BaseAclAction
{
}

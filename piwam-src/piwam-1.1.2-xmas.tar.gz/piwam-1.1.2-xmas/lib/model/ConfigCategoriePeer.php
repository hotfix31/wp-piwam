<?php

class ConfigCategoriePeer extends BaseConfigCategoriePeer
{
}

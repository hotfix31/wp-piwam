<h2>Demander une inscription</h2>
<?php include_partial('form', array('form' => $form, 'pending' => true)) ?>
<?php
/**
 * Parse log files
 *
 * @author  Adrien Mogenet
 * @package fcLogAnalyzerPlugin
 */
class fcLogParser
{
    protected $_file;
    protected $_dateFrom;
    protected $_dateTo;
    protected $_numberOfLines;

    /**
     * Ctor
     *
     * @param   string  $file       File to parse
     * @param   array   $options    Options
     */
    public function __construct($file, $options = array())
    {

    }

    /**
     * Get lines to fetch from the log file
     *
     * @return  array       Fetched lines
     */
    public function getLines()
    {
        $result = array();

        return $result;
    }
}
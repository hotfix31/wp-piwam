<h2>Éditer une cotisation</h2>

<?php include_partial('form', array('form' => $form)) ?>

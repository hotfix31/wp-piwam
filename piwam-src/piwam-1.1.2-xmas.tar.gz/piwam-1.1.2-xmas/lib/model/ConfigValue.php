<?php

class ConfigValue extends BaseConfigValue
{
}

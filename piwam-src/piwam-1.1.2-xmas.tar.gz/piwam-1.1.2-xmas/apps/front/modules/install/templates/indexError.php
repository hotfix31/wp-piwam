<h2>Installation</h2>
<p>Piwam <i>semble</i> déjà être installé... (La connexion à la base de données est correctement configurée, et les tables ont bien été créées)</p>
<p>Bonne nouvelle ?</p>
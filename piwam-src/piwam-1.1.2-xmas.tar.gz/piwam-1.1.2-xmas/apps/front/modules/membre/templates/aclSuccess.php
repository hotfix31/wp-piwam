<h2>Gestion des droits</h2>

<?php include_partial('aclForm', array('form' => $form, 'user_id' => $user_id)) ?>
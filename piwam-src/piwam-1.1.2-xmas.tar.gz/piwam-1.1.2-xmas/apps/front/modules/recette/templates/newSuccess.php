<h2>Enregistrer une recette</h2>

<?php include_partial('form', array('form' => $form)) ?>

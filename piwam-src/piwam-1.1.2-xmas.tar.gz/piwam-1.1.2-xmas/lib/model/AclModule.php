<?php

class AclModule extends BaseAclModule
{
}

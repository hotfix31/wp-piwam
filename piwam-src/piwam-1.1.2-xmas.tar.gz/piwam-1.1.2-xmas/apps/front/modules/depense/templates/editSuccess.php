<h2>Éditer une dépense</h2>

<?php include_partial('form', array('form' => $form)) ?>

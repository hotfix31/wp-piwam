<h2>Erreur pendant la mise à jour</h2>
<p>Une erreur est survenue pendant la mise à jour. N'hésitez pas à demander de
l'aide sur <a href="groups.google.com/group/piwam">groups.google.com/group/piwam</a>
</p>
<pre>
<?php echo $error ?>
</pre>

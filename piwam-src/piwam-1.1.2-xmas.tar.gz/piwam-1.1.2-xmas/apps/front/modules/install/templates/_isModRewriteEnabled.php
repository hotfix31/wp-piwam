<?php
/*
 * Required parameters :
 *
 * $error
 */
?>

<?php if ($error): ?>

    <strong>
        Module <span style="font-family: courier">mod_rewrite</span> : désactivé
    </strong><br />

    Le module Apache <span style="font-family: courier">mod_rewrite</span> n'est
    pas activé

<?php else: ?>

    Le module Apache <span style="font-family: courier">mod_rewrite</span> est
    activé

<?php endif; ?>
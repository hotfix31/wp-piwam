<h2>Fin de la configuration</h2>

<table>
    <tr>
        <td style="padding: 20px;"><?php echo image_tag('ok', array('alt' => 'FIN')) ?></td>
        <td>
            <p>Félicitations. Vous venez d'installer <strong>Piwam</strong> correctement</p>
            <p>Vous pouvez dès maintenant <?php echo link_to('enregistrer votre association', 'association/new') ?>.</p>
        </td>
    </tr>
</table>
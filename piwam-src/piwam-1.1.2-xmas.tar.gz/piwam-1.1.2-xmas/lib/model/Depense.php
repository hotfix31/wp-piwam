<?php

class Depense extends BaseDepense
{
}

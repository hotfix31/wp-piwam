<h2>Compte correctement créé !</h2>
<p>Merci de faire confiance à <i>Piwam</i> pour gérer votre association ! Les
informations saisies ont correctement été enregistrées.</p>
<p>Vous pouvez dès à présent <?php echo link_to('vous authentifier', 'association/login') ?>
&nbsp;pour accéder à l'espace de gestion de votre association.</p>

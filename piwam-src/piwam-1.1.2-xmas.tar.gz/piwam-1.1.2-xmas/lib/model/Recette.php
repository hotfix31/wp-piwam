<?php

class Recette extends BaseRecette
{
}

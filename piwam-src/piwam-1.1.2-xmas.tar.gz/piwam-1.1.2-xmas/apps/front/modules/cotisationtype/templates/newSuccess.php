<h2>Nouveau type de cotisation</h2>

<?php include_partial('form', array('form' => $form)) ?>

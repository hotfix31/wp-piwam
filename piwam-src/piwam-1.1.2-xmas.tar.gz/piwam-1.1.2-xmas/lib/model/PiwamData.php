<?php

class PiwamData extends BasePiwamData
{
}

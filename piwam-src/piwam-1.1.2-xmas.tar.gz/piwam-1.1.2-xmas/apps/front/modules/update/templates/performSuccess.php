<h2>Mise à jour de Piwam</h2>
<p>La mise à jour a été effectuée avec succès.</p>

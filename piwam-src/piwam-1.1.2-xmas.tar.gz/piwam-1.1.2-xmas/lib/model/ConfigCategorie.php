<?php

class ConfigCategorie extends BaseConfigCategorie
{
}

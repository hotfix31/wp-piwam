<h2>Nouvelle activité</h2>

<?php include_partial('form', array('form' => $form)) ?>

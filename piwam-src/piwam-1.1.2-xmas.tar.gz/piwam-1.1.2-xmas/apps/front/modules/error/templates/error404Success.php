<h2>Page introuvable</h2>
<p>La page à laquelle vous essayez d'accéder n'existe pas. <br />
Si vous pensez que cela est une erreur de l'application, n'hésitez pas à
reporter le problème sur <a href="http://piwam.googlecode.com/">le site de Piwam</a>.
</p>
